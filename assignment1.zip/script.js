async function fetchProducts(sortOrder) {
    const response = await fetch(`https://fakestoreapi.com/products?sort=${sortOrder}`);
    const products = await response.json();
    return products;
  }
  
  function displayProducts(products) {
    const productsContainer = document.getElementById('productsContainer');
    productsContainer.innerHTML = '';
  
    products.forEach(product => {
      const productCard = document.createElement('div');
      productCard.classList.add('product-card');
  
      const productImage = document.createElement('img');
      productImage.src = product.image;
      productImage.alt = product.title;
      productCard.appendChild(productImage);
  
      const productDetails = document.createElement('div');
      productDetails.classList.add('product-details');
  
      const productName = document.createElement('h2');
      productName.textContent = product.title;
      productDetails.appendChild(productName);
  
      const productPrice = document.createElement('p');
      productPrice.textContent = `$${product.price}`;
      productDetails.appendChild(productPrice);
  
      productCard.appendChild(productDetails);
  
      productsContainer.appendChild(productCard);
    });
  }
  
  document.getElementById('sortSelect').addEventListener('change', async function(event) {
    const sortOrder = event.target.value;
    const products = await fetchProducts(sortOrder);
    displayProducts(products);
  });
  
  
  fetchProducts('asc').then(displayProducts);
  